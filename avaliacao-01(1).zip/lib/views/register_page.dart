import 'package:flutter_chat_app/components/auth_button.dart';
import 'package:flutter_chat_app/components/confirm_button.dart';
import 'package:flutter_chat_app/components/custom_input.dart';
import 'package:flutter_chat_app/services/auth_service.dart';
import 'package:flutter_chat_app/utils/show_message.dart';
import 'package:flutter_chat_app/views/login_page.dart';
import 'package:flutter/material.dart';

class RegisterPage extends StatelessWidget {
  RegisterPage({super.key});

  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Cadastro'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
      ),
      body: Column(
        children: [
          Container(
            width: 400,
            height: 200,
            child: Icon(
              Icons.download_done, // Você pode usar qualquer ícone
              size: 200,
              color: Color(0xffffffff), // Cor do ícone
            ),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Color(0xff004cff), // Cor inicial
                  Color(0xffffffff), // Cor final
                ],
                begin: Alignment.topCenter, // Ponto de início do degradê
                end: Alignment.bottomCenter, // Ponto final do degradê),
                //SizedBox(width: 400, height: 300),
              ),
            ),
          ),
          // const Text(
          //   'Cadastro',
          //   style: TextStyle(
          //     fontSize: 26,
          //     fontWeight: FontWeight.bold,
          //   ),
          // ),
          const SizedBox(
            height: 20,
          ),
          CustomInput(
            controller: nameController,
            labelText: 'Nome',
          ),
          CustomInput(
            controller: emailController,
            labelText: 'Email',
          ),
          CustomInput(
            controller: phoneController,
            labelText: 'Telefone',
          ),
          CustomInput(
            controller: passwordController,
            labelText: 'Senha',
            isObscure: true,
          ),
          CustomInput(
            controller: confirmController,
            labelText: 'Repita sua Senha',
            isObscure: true,
          ),
          ConfirmButton(
            onPressed: () async {
              try {
                await FirebaseAuthService().register(
                  nameController.text,
                  phoneController.text,
                  emailController.text,
                  passwordController.text,
                );

                Navigator.of(context).pushReplacement(
                  MaterialPageRoute(
                    builder: (context) => LoginPage(),
                  ),
                );
              } catch (e) {
                showMessage(context, e);
              }
            },
            labelText: 'Cadastrar',
          ),
        ],
      ),
    );
  }
}
