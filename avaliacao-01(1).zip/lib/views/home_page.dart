import 'package:flutter_chat_app/components/auth_button.dart';
import 'package:flutter_chat_app/components/confirm_button.dart';
import 'package:flutter_chat_app/components/custom_input.dart';
import 'package:flutter_chat_app/views/feedback_page.dart';
import 'package:flutter_chat_app/views/register_page.dart';
import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(0.0),
        child: Column(
          children: [
            Container(
              width: 400,
              height: 500,
              child: Icon(
                Icons.apps, // Você pode usar qualquer ícone
                size: 200,
                color: Color(0xffffffff), // Cor do ícone
              ),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Color(0xff004cff), // Cor inicial
                    Color(0xffffffff), // Cor final
                  ],
                  begin: Alignment.topCenter, // Ponto de início do degradê
                  end: Alignment.bottomCenter, // Ponto final do degradê),
                  //SizedBox(width: 400, height: 300),
                ),
              ),
            ),
            ConfirmButton(
              labelText: 'Registrar',
              onPressed: () async {
                try {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => RegisterPage(),
                    ),
                  );
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      backgroundColor: Colors.red,
                      content: Text(
                        e.toString(),
                      ),
                    ),
                  );
                }
              },
            ),
            ConfirmButton(
              labelText: 'Feedback',
              onPressed: () async {
                try {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => FeedPage(),
                    ),
                  );
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      backgroundColor: Colors.red,
                      content: Text(
                        e.toString(),
                      ),
                    ),
                  );
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}
