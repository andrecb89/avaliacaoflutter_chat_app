import 'package:flutter/material.dart';

class AuthButton extends StatelessWidget {
  String image;

  AuthButton({super.key, required this.image});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 0, horizontal: 25),
      padding: const EdgeInsets.all(0),
      width: 30,
      height: 30,
      decoration: BoxDecoration(
          color: Color.fromARGB(34, 117, 128, 127),
          borderRadius: BorderRadius.circular(10)),
      child: Image.network(
        image,
      ),
    );
  }
}
