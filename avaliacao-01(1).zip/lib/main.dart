import 'package:flutter_chat_app/firebase_options.dart';
import 'package:flutter_chat_app/views/feedback_page.dart';
import 'package:flutter_chat_app/views/home_page.dart';
import 'package:flutter_chat_app/views/login_page.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_chat_app/views/register_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(
    MaterialApp(
      home: HomePage(),
      theme: ThemeData(useMaterial3: false),
    ),
  );
}
